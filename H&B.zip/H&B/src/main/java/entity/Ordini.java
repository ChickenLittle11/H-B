package entity;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "als_jason")
@Data
public class Ordini implements Serializable
{
	private static final long serialVersionUID = 291353626011036772L;
	
	@Id
	@Column(name = "purchase_order_number")
	private String purchaseOrderNumber;
	
	@Column(name = "vendor_code")
	private String vendorCode;
	
	@Column(name = "delivery_company_name")
	private String deliveryCompanyName;
	
	@Column(name = "checknet")
	private String checknet;
	
	@Column(name = "checknet_response_code")
	private String checknetResponseCode;
}
