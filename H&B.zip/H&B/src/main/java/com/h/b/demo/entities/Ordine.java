package com.h.b.demo.entities;

import javax.persistence.Column;
import javax.persistence.Transient;

import org.springframework.data.annotation.Id;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "als_json")
@Data
public class Ordine {
	@Id
    @Column(name = "purchase_order_number")
    private String purchaseOrderNumber;

    @Column(name = "vendor_code")
    private String vendorCode;

    @Column(name = "delivery_company_name")
    private String deliveryCompanyName;

    @Column(name = "checknet")
    private String checknet;

    @Column(name = "checknet_response_code")
    private int checknetResponseCode;

    @Transient
    private int countAll;

    @Transient
    private int countDistinctSerialNumber;
	
}
