package com.h.b.demo.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name = "als_json")
public class InfoOrdine {
    
    @Column(name = "product_code")
    private String productCode;

    @Column(name = "gtin")
    private String gtin;

    @Column(name = "serial_number")
    private String serialNumber;

    @Column(name = "variant")
    private String variant;

    @Column(name = "part")
    private String part;

    @Column(name = "colour_code")
    private String colourCode;

    @Column(name = "size")
    private String size;

    @Column(name = "size_cod")
    private String sizeCod;

    @Column(name = "product_description")
    private String productDescription;

    @Column(name = "checknet")
    private String checknet;

}
