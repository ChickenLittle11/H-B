package com.h.b.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.crossstore.ChangeSetPersister.NotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.h.b.demo.dtos.InfoOrdineDto;
import com.h.b.demo.dtos.OrdineDto;
import com.h.b.demo.services.InfoOrdineService;
import com.h.b.demo.services.OrdineService;
import lombok.extern.java.Log;

@RestController
@RequestMapping("api/als_json")
@Log
@CrossOrigin("http://localhost:4200")
public class OrdiniController {

	
	@Autowired 
	private OrdineService ordineService;
	
	@GetMapping(value = "/filtro", produces = "application/json")
	public ResponseEntity<List<OrdineDto>> SelByFiltro(
			@RequestParam("purchaseOrderNumber") String purchaseOrderNumber,
            @RequestParam("vendorCode") String vendorCode,
            @RequestParam("checknetResponseCode") int checknetResponseCode)
			throws NotFoundException	
	{
		log.info("****** Otteniamo gli elementi dalla tabella *******");
		
		List<OrdineDto> ordini = ordineService.SelByFiltro(purchaseOrderNumber,vendorCode ,checknetResponseCode);
		
		if (ordini == null)
		{
			String ErrMsg = String.format("I filtri impostati non hanno prodotto risultati");
			
			log.warning(ErrMsg);
			
			throw new NotFoundException();
		}
		 
		return new ResponseEntity<List<OrdineDto>>(ordini, HttpStatus.OK);
		
	}
	
	@Autowired
    private InfoOrdineService infoOrdineService;

	@GetMapping(value = "/dettaglio", produces = "application/json")
    public ResponseEntity<List<InfoOrdineDto>> getDettaglio(
            @RequestParam("purchaseOrderNumber") String purchaseOrderNumber,
            @RequestParam("checknet") String checknet) {
        
        List<InfoOrdineDto> dettaglio = infoOrdineService.getDettaglio(purchaseOrderNumber, checknet);

        return new ResponseEntity<List<InfoOrdineDto>>(dettaglio, HttpStatus.OK);
    }
}
