package com.h.b.demo.dtos;

import lombok.Data;

@Data
public class OrdineDto {
	
	private String purchaseOrderNumber;
    private String vendorCode;
    private String deliveryCompanyName;
    private String checknet;
    private int checknetResponseCode;
    private int countAll;
    private int countDistinctSerialNumber;

}
