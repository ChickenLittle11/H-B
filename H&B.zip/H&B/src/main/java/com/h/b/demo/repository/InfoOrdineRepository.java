package com.h.b.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.h.b.demo.entities.InfoOrdine;

public interface InfoOrdineRepository {
	
	@Query(value = "SELECT\n"
			+ "  product_code,\n"
			+ "  gtin,\n"
			+ "  serial_number,\n"
			+ "  variant,\n"
			+ "  part,\n"
			+ "  colour_code,\n"
			+ "  size,\n"
			+ "  size_cod,\n"
			+ "  product_description,\n"
			+ "  purchase_order_number,\n"
			+ "  checknet\n"
			+ "FROM als_json\n"
			+ "WHERE purchase_order_number = ':purchaseOrderNumber'\n"
			+ "AND checknet = ':checknet';", nativeQuery = true)
	List<InfoOrdine> getDettaglio(
	        @Param("purchaseOrderNumber") String purchaseOrderNumber,
	        @Param("checknet") String checknet);

}
