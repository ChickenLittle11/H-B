package com.h.b.demo.services;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.h.b.demo.dtos.OrdineDto;
import com.h.b.demo.entities.Ordine;
import com.h.b.demo.repository.OrdineRepository;
@Service
@Transactional(readOnly = true)
public class OrdineServiceImpl implements OrdineService{
	@Autowired
	OrdineRepository ordineRepository;
	
	@Autowired
	private ModelMapper modelMapper;

	@Override
	public List<OrdineDto> SelByOrderNumber(String purchaseOrderNumber) {
		List<Ordine> ordini = ordineRepository.SelByOrderNumber(purchaseOrderNumber);
		return ordini.stream()
				.map(ordine -> modelMapper.map(ordine, OrdineDto.class))
                .collect(Collectors.toList());
	}

	@Override
    public List<OrdineDto> SelByVendorCode(String vendorCode) {
        List<Ordine> ordini = ordineRepository.SelByVendorCode(vendorCode);
        return ordini.stream()
                .map(ordine -> modelMapper.map(ordine, OrdineDto.class))
                .collect(Collectors.toList());
	}

	@Override
    public List<OrdineDto> SelByChecknetResponseCode(int checknetResponseCode) {
        List<Ordine> ordini = ordineRepository.SelByChecknetResponseCode(checknetResponseCode);
        return ordini.stream()
                .map(ordine -> modelMapper.map(ordine, OrdineDto.class))
                .collect(Collectors.toList());
    }

	@Override
    public Iterable<Ordine> SelTutti() {
        return ordineRepository.findAll();
    }

	@Override
    public List<OrdineDto> SelByFiltro(
            String purchaseOrderNumber,
            String vendorCode,
            int checknetResponseCode) {

        List<Ordine> ordini = ordineRepository.SelByFilters(
                purchaseOrderNumber, vendorCode, checknetResponseCode);

        return ordini.stream()
                .map(ordine -> modelMapper.map(ordine, OrdineDto.class))
                .collect(Collectors.toList());
    }

}
