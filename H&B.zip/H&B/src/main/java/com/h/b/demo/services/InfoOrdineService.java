package com.h.b.demo.services;

import java.util.List;

import com.h.b.demo.dtos.InfoOrdineDto;

public interface InfoOrdineService {
    List<InfoOrdineDto> getDettaglio(String purchaseOrderNumber, String checknet);
}

