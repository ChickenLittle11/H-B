package com.h.b.demo.dtos;

import lombok.Data;

@Data
public class InfoOrdineDto {
	
	private String productCode;
    private String gtin;
    private String serialNumber;
    private String variant;
    private String part;
    private String colourCode;
    private String size;
    private String sizeCod;
    private String productDescription;
    private String purchaseOrderNumber;
	
}
