package com.h.b.demo.services;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.h.b.demo.dtos.InfoOrdineDto;
import com.h.b.demo.entities.InfoOrdine;
import com.h.b.demo.repository.InfoOrdineRepository;

@Service
public class InfoOrdineServiceImpl implements InfoOrdineService {

    @Autowired
    private InfoOrdineRepository infoOrdineRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public List<InfoOrdineDto> getDettaglio(String purchaseOrderNumber, String checknet) {
        List<InfoOrdine> dettagli = infoOrdineRepository.getDettaglio(
                purchaseOrderNumber, checknet);

        return dettagli.stream()
                .map(dettaglio -> modelMapper.map(dettaglio, InfoOrdineDto.class))
                .collect(Collectors.toList());
    }

}