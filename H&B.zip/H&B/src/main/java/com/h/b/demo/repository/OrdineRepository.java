package com.h.b.demo.repository;

import com.h.b.demo.entities.*;

import java.util.List;

import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;

public interface OrdineRepository extends JpaRepository<Ordine, String>{
	
	

	@Query(value = "SELECT\n"
			+ "    purchase_order_number,\n"
			+ "    vendor_code,\n"
			+ "    delivery_company_name,\n"
			+ "    checknet,\n"
			+ "    checknet_response_code,\n"
			+ "    COUNT(*) as count_all,\n"
			+ "    COUNT(DISTINCT serial_number) as count_distinct_serial_number\n"
			+ "FROM\n"
			+ "    als_json\n"
			+ "WHERE\n"
			+ "    purchase_order_number = ':purchaseOrderNumber'\n"
			+ "GROUP BY\n"
			+ "    purchase_order_number,\n"
			+ "    vendor_code,\n"
			+ "    delivery_company_name,\n"
			+ "    checknet,\n"
			+ "    checknet_response_code;", nativeQuery = true)
	List<Ordine> SelByOrderNumber(@Param("purchaseOrderNumber") String purchaseOrderNumber);
	
	@Query(value = "SELECT\n"
			+ "    purchase_order_number,\n"
			+ "    vendor_code,\n"
			+ "    delivery_company_name,\n"
			+ "    checknet,\n"
			+ "    checknet_response_code,\n"
			+ "    COUNT(*) as count_all,\n"
			+ "    COUNT(DISTINCT serial_number) as count_distinct_serial_number\n"
			+ "FROM\n"
			+ "    als_json\n"
			+ "WHERE\n"
			+ "    vendor_code = ':vendorCode'\n"
			+ "GROUP BY\n"
			+ "    purchase_order_number,\n"
			+ "    vendor_code,\n"
			+ "    delivery_company_name,\n"
			+ "    checknet,\n"
			+ "    checknet_response_code;", nativeQuery = true)
	List<Ordine> SelByVendorCode(@Param("vendorCode") String vendorCode);
	
	@Query(value = "SELECT\n"
			+ "    purchase_order_number,\n"
			+ "    vendor_code,\n"
			+ "    delivery_company_name,\n"
			+ "    checknet,\n"
			+ "    checknet_response_code,\n"
			+ "    COUNT(*) as count_all,\n"
			+ "    COUNT(DISTINCT serial_number) as count_distinct_serial_number\n"
			+ "FROM\n"
			+ "    als_json\n"
			+ "WHERE\n"
			+ "    checknet_response_code = :checknetResponseCode\n"
			+ "GROUP BY\n"
			+ "    purchase_order_number,\n"
			+ "    vendor_code,\n"
			+ "    delivery_company_name,\n"
			+ "    checknet,\n"
			+ "    checknet_response_code;", nativeQuery = true)
	List<Ordine> SelByChecknetResponseCode(@Param("checknetResponseCode") int checknetResponseCode);
	
	
	@Query(value = "SELECT\n"
	        + "    purchase_order_number,\n"
	        + "    vendor_code,\n"
	        + "    delivery_company_name,\n"
	        + "    checknet,\n"
	        + "    checknet_response_code,\n"
	        + "    COUNT(*) as count_all,\n"
	        + "    COUNT(DISTINCT serial_number) as count_distinct_serial_number\n"
	        + "FROM\n"
	        + "    als_json\n"
	        + "WHERE\n"
	        + "    (:purchaseOrderNumber IS NULL OR purchase_order_number = :purchaseOrderNumber)\n"
	        + "    AND (:vendorCode IS NULL OR vendor_code = :vendorCode)\n"
	        + "    AND (:checknetResponseCode IS NULL OR checknet_response_code = :checknetResponseCode)\n"
	        + "GROUP BY\n"
	        + "    purchase_order_number,\n"
	        + "    vendor_code,\n"
	        + "    delivery_company_name,\n"
	        + "    checknet,\n"
	        + "    checknet_response_code;", nativeQuery = true)
	List<Ordine> SelByFilters(
	        @Param("purchaseOrderNumber") String purchaseOrderNumber,
	        @Param("vendorCode") String vendorCode,
	        @Param("checknetResponseCode") Integer checknetResponseCode);
}
