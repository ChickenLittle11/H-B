package com.h.b.demo.services;

import java.util.List;

import com.h.b.demo.dtos.OrdineDto;
import com.h.b.demo.entities.Ordine;

public interface OrdineService {
	
	public List<OrdineDto> SelByOrderNumber(String purchaseOrderNumber);

	public List<OrdineDto> SelByVendorCode(String vendorCode);
	
	public List<OrdineDto> SelByChecknetResponseCode(int checknetResponseCode);
	
	public Iterable<Ordine> SelTutti();
	
	public List<OrdineDto> SelByFiltro(String purchaseOrderNumber,String vendorCode,int checknetResponseCode );
	

}
