package repository;

import org.springframework.data.repository.PagingAndSortingRepository;

import entity.Ordini;


public interface OrdiniRepository extends PagingAndSortingRepository<Ordini, String>
{
	@Query(value = "Tabella contenenente i campi:\r\n"
			+ "- purchase_order_number\r\n"
			+ "- vendor_code\r\n"
			+ "- delivery_company_name\r\n"
			+ "- checknet\r\n"
			+ "- checknet_response_code\r\n"
			+ "- count(0)\r\n"
			+ "- count(distinct(serial_number))", nativeQuery = true)
	List<Ordini>
}
